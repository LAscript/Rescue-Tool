fx_version 'cerulean'
game 'gta5'

author 'LAscript'
description 'Rescue Tools Script'
version '1.0.0'

lua54 'yes'

client_scripts {
    'config.lua',
    'client.lua',
    'fxmanifest.lua',
    'server.lua'
}
