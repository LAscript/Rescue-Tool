Config = {}

Config.Tools = {
    ["spreader"] = {
        model = "prop_tool_jackham",
        animDict = "amb@world_human_hammering@male@base",
        animName = "base",
        offset = { x = 0.1, y = 0.02, z = -0.02 },
        rotation = { x = 0.0, y = 90.0, z = 180.0 }
    },
    ["cutters"] = {
        model = "prop_tool_saw01",
        animDict = "amb@world_human_welding@male@base",
        animName = "base",
        offset = { x = 0.13, y = 0.02, z = -0.03 },
        rotation = { x = 0.0, y = 90.0, z = 170.0 }
    },
    ["k12"] = {
        model = "prop_tool_consaw",
        animDict = "amb@world_human_welding@male@base",
        animName = "base",
        offset = { x = 0.12, y = 0.01, z = -0.07 },
        rotation = { x = 0.0, y = 90.0, z = 180.0 }
    },
    ["pipepole"] = {
        model = "prop_cs_crowbar",
        animDict = "amb@world_human_hammering@male@base",
        animName = "base",
        offset = { x = 0.15, y = 0.01, z = -0.01 },
        rotation = { x = 0.0, y = 90.0, z = 180.0 }
    },
    ["stabilizers"] = {
        model = "prop_tool_box_04",
        animDict = "amb@prop_human_bum_bin@idle_b",
        animName = "idle_d",
        offset = { x = 0.12, y = 0.02, z = -0.01 },
        rotation = { x = 0.0, y = 90.0, z = 180.0 }
    },
    ["tripod"] = {
        model = "prop_tripod",
        animDict = "amb@prop_human_bum_bin@idle_b",
        animName = "idle_c",
        offset = { x = 0.12, y = 0.01, z = 0.0 },
        rotation = { x = 0.0, y = 90.0, z = 180.0 }
    }
}
