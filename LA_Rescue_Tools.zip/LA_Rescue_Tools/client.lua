local currentTool = nil
local isCutting = false
local attachedProp = nil
local inVehicleRange = false
local targetVehicle = nil
local doorIndex = nil

-- Handle Tool Commands
RegisterCommand("tool", function(source, args, rawCommand)
    local tool = args[1]
    if tool and Config.Tools[tool] then
        currentTool = tool
        GiveToolToPlayer(tool)
    else
        ShowNotification("~r~Invalid tool name.")
    end
end, false)

RegisterCommand("removetool", function()
    RemoveToolFromPlayer()
end, false)

-- Handle E key for cutting with K12 tool
CreateThread(function()
    while true do
        Wait(0)

        -- Check if player is holding the K12 tool and close to a vehicle
        if currentTool == "k12" then
            local playerPed = PlayerPedId()
            local coords = GetEntityCoords(playerPed)
            targetVehicle = GetClosestVehicle(coords, 5.0, 0, 70) -- Check for vehicles within 5 meters

            if DoesEntityExist(targetVehicle) then
                doorIndex = GetFirstIntactDoor(targetVehicle)
                if doorIndex then
                    inVehicleRange = true
                    -- Show prompt to press E to start cutting
                    ShowHelpText("Press ~INPUT_CONTEXT~ to cut the door off.")
                    if IsControlJustReleased(0, 38) and not isCutting then -- 38 = E key
                        isCutting = true
                        StartCuttingAnimation()
                        Wait(2000) -- Simulate cutting time
                        SetVehicleDoorBroken(targetVehicle, doorIndex, true)
                        ClearPedTasks(playerPed)
                        isCutting = false
                    end
                else
                    inVehicleRange = false
                    ShowNotification("~r~No intact doors found on this vehicle.")
                end
            else
                inVehicleRange = false
                ShowNotification("~r~No vehicle nearby.")
            end
        end
    end
end)

-- Helper function to give the tool
function GiveToolToPlayer(tool)
    local playerPed = PlayerPedId()
    local toolModel = Config.Tools[tool].model
    RequestModel(toolModel)
    while not HasModelLoaded(toolModel) do
        Wait(10)
    end

    -- Attach the K12 tool to the player's hand
    attachedProp = CreateObjectNoOffset(toolModel, 0, 0, 0, true, true, true)
    
    -- Position the tool in front of the player
    AttachEntityToEntity(attachedProp, playerPed, GetPedBoneIndex(playerPed, 57005), 
        0.12, -- X offset (position the tool slightly in front of the player)
        0.0,  -- Y offset (keep it centered)
        0.05, -- Z offset (position the tool at a reasonable height)
        90.0, -- Rotation X (rotate the tool to point forward)
        0.0,  -- Rotation Y (no rotation)
        180.0, -- Rotation Z (align it correctly with the player's hand)
        true, true, false, true, 1, true)
end

-- Helper function to remove the tool
function RemoveToolFromPlayer()
    if attachedProp then
        DeleteEntity(attachedProp)
        attachedProp = nil
    end
    currentTool = nil
end

-- Helper function to get first intact door
function GetFirstIntactDoor(vehicle)
    for i = 0, 5 do
        if not IsVehicleDoorDamaged(vehicle, i) then
            return i
        end
    end
    return nil
end

-- Helper function to start the cutting animation
function StartCuttingAnimation()
    local ped = PlayerPedId()
    RequestAnimDict("amb@world_human_welding@male@base")
    while not HasAnimDictLoaded("amb@world_human_welding@male@base") do
        Wait(10)
    end
    TaskPlayAnim(ped, "amb@world_human_welding@male@base", "base", 8.0, -8.0, -1, 1, 0, false, false, false)

    -- Optional: spark effect
    local coords = GetEntityCoords(ped)
    UseParticleFxAssetNextCall("core")
    StartParticleFxNonLoopedAtCoord("ent_sparking_wires", coords.x, coords.y, coords.z + 0.8, 0.0, 0.0, 0.0, 1.0, false, false, false)
end

-- Helper function to show notifications
function ShowNotification(text)
    BeginTextCommandThefeedPost("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandThefeedPostTicker(false, false)
end

-- Helper function to show "Help Text" for key prompts
function ShowHelpText(text)
    SetTextComponentFormat("STRING")
    AddTextComponentString(text)
    DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end
