CreateThread(function()
    Wait(500) -- short delay to avoid clutter with txAdmin boot logs
    print("^3===================================================")
    print("^2Rescue Tools Script ^7- ^5Standalone by LA")
    print("^3Version:^7 1.0.0")
    print("^3Status:^7 Successfully loaded!")
    print("^3GitHub:^7 https://github.com/LAscript/rescue-tools (if applicable)")
    print("^3===================================================^0")
end)
